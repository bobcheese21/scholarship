import pymysql
import sys


REGION = 'us-west-2a'

rds_host  = "holdmyass.cpsqgunrlwjm.us-west-2.rds.amazonaws.com"
name = "holdmyass"
password = "holdmyasspassword"
db_name = "holdmyass"


def save_events(event):
    """
    This function fetches content from mysql RDS instance
    """
    result = []
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    with conn.cursor() as cur:
        cur.execute("""insert into tbl_classes (ClassID, Dept, ClassNum, ClassDesc) values( %s, '%s', '%s', '%s)""" % (event['ClassID'], event['Dept'], event['ClassNum'], event['ClassDesc']))
        cur.execute("""select * from tbl_classes""")
        conn.commit()
        cur.close()
        for row in cur:
            result.append(list(row))

def main(event,context):
    save_events(event)
